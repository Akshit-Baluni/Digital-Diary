CREATE DATABASE IF NOT EXISTS digital_diary;
USE digital_diary;

CREATE TABLE IF NOT EXISTS entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date VARCHAR(20),
    title VARCHAR(100) UNIQUE,
    content TEXT
);

-- INSERT INTO entries (date, title, content) VALUES
-- ('2025-04-01', 'First Note', 'This is my first note.'),
-- ('2025-04-02', 'Grocery List', 'Buy milk, eggs, bread, and coffee.'),
-- ('2025-04-03', 'Meeting Notes', 'Discuss project timeline and deliverables.'),
-- ('2025-04-04', 'Book Ideas', 'Story about time-traveling artist.'),
-- ('2025-04-05', 'Workout Plan', 'Monday: Chest\nTuesday: Back\nWednesday: Legs'),
-- ('2025-04-06', 'Travel Bucket List', 'Visit Japan, Iceland, and New Zealand.'),
-- ('2025-04-07', 'Java Learning', 'Practice JDBC and Swing daily.'),
-- ('2025-04-08', 'Birthday Reminders', 'Mom: Jan 5, Dad: Feb 10, Bestie: Aug 20'),
-- ('2025-04-09', 'Recipe - Pasta', 'Boil pasta, sauté garlic, add tomato sauce.'),
-- ('2025-04-10', 'Quote Collection', '“Be yourself; everyone else is already taken.” – Oscar Wilde'),
-- ('2025-04-11', 'App Ideas', 'Notes app with search, filters, and cloud sync.');

SELECT * FROM entries;